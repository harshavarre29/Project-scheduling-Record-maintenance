package ProjectManagement;


public class Project {
//name,budget&priority
	String name;
	int priority;
	int budget;
	Project(String name,int priority,int budget){
		this.name=name;
		this.priority=priority;
		this.budget=budget;
	}
}
